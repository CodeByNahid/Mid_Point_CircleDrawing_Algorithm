#include <GL/glut.h>
#include<bits/stdc++.h>
#include <stdlib.h>
using namespace std;
int cx,cy,r;
void eightWay(int cx, int cy, int x, int y)
{
    glVertex2i(cx + x, cy + y);
    glVertex2i(cx - x, cy + y);
    glVertex2i(cx + x, cy - y);
    glVertex2i(cx - x, cy - y);
    glVertex2i(cx + y, cy + x);
    glVertex2i(cx - y, cy + x);
    glVertex2i(cx + y, cy - x);
    glVertex2i(cx - y, cy - x);
}

  void circleDrawing(int cx,int cy,int r){

  int x=0;
  int y=r;
  int p=1-r;
  while(x<=y){
         eightWay(cx, cy, x, y);
    if(p<0){
        int prev_x=x;
        int prev_y=y;
        x+=1;
        p=p+2*prev_x+3;
    }
    else
    {
        int prev_x=x;
        int prev_y=y;
        x+=1;
        y-=1;
        p=p+2*prev_x-2*prev_y+5;

    }
  }

  }



static void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, 640, 0, 480);
    glColor3d(1,0,0);
    glPointSize(3.0);
    glBegin(GL_POINTS);

    circleDrawing(cx,cy,r);

    glEnd();
    glFlush();


}

int main(int argc, char *argv[])
{
    cout<<"Enter the center Of the Circle: "<<endl;
    cin>>cx>>cy;
    cout<<"Enter the Radius Of the Circle: "<<endl;
    cin>>r;
    glutInit(&argc, argv);
    glutInitWindowSize(640,480);
    glutInitWindowPosition(10,10);
    glutInitDisplayMode(GLUT_RGB | GLUT_SINGLE | GLUT_DEPTH);

    glutCreateWindow("Circle Drawing");
    glutDisplayFunc(display);

    glClearColor(0,0,0,1);

    glutMainLoop();

    return EXIT_SUCCESS;
}
